export interface ActivityCard {
      titulo:string;
      descripcion:string;
      fecha:string;
      estado:string;
      extraInfo:string;
}
